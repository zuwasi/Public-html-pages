(* ============================================================
   Q-Wave Planner - Wolfram exact + QAOA pipeline
   Demo: "Which systems should a bank migrate to post-quantum
   cryptography this quarter?" (Q.security focus)

   MantiQ Factor stage 4 (Compute) plus the Wolfram Quantum
   Framework cross-check: the QAOA circuit is rebuilt with
   QuantumCircuitOperator / QuantumOperator objects (the same
   matrices as the analytic path, verified to machine precision),
   and a seeded 4096-shot sample is drawn from the exact p=1
   statevector. The sample is a seeded sample of the exact
   distribution, not a circuit-sampling run.

   Angle optimization (post-review): the earlier pipeline used a
   97x49 grid plus NMinimize confined to a +-0.2 box, whose
   "optimized" beta was the box edge, not an optimum. This build
   uses a dense gamma grid (2401 points per 2*pi, far denser than
   the 2*cost-span Nyquist bound) times a dense beta grid, then
   unconstrained local refinement from the best grid points - no
   search box. p=2 is a multi-start local search (best found, not
   certified global) and is labeled as such wherever it is quoted.

   Inputs (written by earlier stages, every number traceable):
     data/instance.json        six migration projects, budget, Q-day distribution
     data/results/scoring.json exposure scores from the Gupta & Mittal 2026 model
     data/results/plans.json   exact enumeration, optima, ranked-list plans

   Independent recomputation in this script:
     - the 64-plan enumeration and both optima (cross-checked)
     - the Gupta-Mittal Monte Carlo E[f] (cross-checked)
     - QAOA p=1 and p=2 exact statevectors, honest angle search
     - Quantum Framework matrix rebuild + seeded 4096-shot sampler
     - the budget-12 -> 16 live event, full re-optimization

   Run:  wolframscript -file wolfram\qwave_planner.wl
   Output: wolfram/qwave_planner.json, charts/*.png
   Verified with Wolfram 15.x, QuantumFramework paclet 1.6.5.
   ============================================================ *)

Needs["Wolfram`QuantumFramework`"];

here = DirectoryName[$InputFileName];
root = FileNameJoin[{here, ".."}];

(* This Wolfram build imports JSON as nested Rule lists, not Associations;
   convert recursively so every lookup below works. *)
toAssoc[r_Rule] := Rule[r[[1]], toAssoc[r[[2]]]];
toAssoc[l_List] := Module[{res = toAssoc /@ l},
   If[Length[res] > 0 && AllTrue[res, Head[#] === Rule &], Association @@ res, res]];
toAssoc[x_] := x;
loadJSON[path_] := toAssoc @ Import[path, "JSON"];

inst = loadJSON[FileNameJoin[{root, "data", "instance.json"}]];
scoreData = loadJSON[FileNameJoin[{root, "data", "results", "scoring.json"}]];
planData = loadJSON[FileNameJoin[{root, "data", "results", "plans.json"}]];

fail[msg_] := (Print["ASSERTION FAILED: ", msg]; Exit[1]);
pass[msg_] := (Print["PASS: ", msg]);
(* formatted numbers as strings, so Print does not emit raw NumberForm wrappers *)
nf[x_, d_] := ToString[NumberForm[x, d]];

projects = inst["projects"];
n = Length[projects];
ids = projects[[All, "id"]];
costs = projects[[All, "cost_weeks"]];
vals = AssociationThread[Lookup[scoreData["projects"], "id"], Lookup[scoreData["projects"], "exposure_points"]] /@ ids;
budget12 = inst["budget_weeks_default"];
budget16 = inst["budget_weeks_live"];

(* dependency: position (1-based) of the prerequisite project, 0 if none *)
prereqIdx = Table[
   With[{req = Lookup[projects[[k]], "requires"]},
     If[MissingQ[req], 0, First @ First @ Position[ids, req]]],
   {k, n}];

Print["projects: ", StringRiffle[ids, ", "]];
Print["costs (weeks): ", costs];
Print["exposure points: ", vals];
Print["prerequisite index (0 = none): ", prereqIdx];

(* ---------- 1. independent enumeration (LSB-first bits: project k <-> bit k-1) ---------- *)
costAssoc = AssociationThread[ids, costs];
valAssoc = AssociationThread[ids, vals];
bitsOf[mask_Integer] := Reverse @ IntegerDigits[mask, 2, n];  (* bitsOf[[k]] = selection of project k *)
membersOf[mask_Integer] := Pick[ids, bitsOf[mask], 1];
maskOf[members_List] := Total[Table[2^(k - 1) Boole[MemberQ[members, ids[[k]]]], {k, n}]];
costOf[members_List] := Total[Lookup[costAssoc, members]];
valueOf[members_List] := Total[Lookup[valAssoc, members]];
feasible[members_List, budget_] := Module[{req},
   If[costOf[members] > budget, Return[False]];
   And @@ Table[
     req = Lookup[projects[[k]], "requires"];
     If[MissingQ[req] || ! MemberQ[members, ids[[k]]], True, MemberQ[members, req]],
     {k, n}]];
feasible[mask_Integer, budget_] := feasible[membersOf[mask], budget];
costOf[mask_Integer] := costOf[membersOf[mask]];
valueOf[mask_Integer] := valueOf[membersOf[mask]];

allMasks = Range[0, 2^n - 1];
feasibleQ[budget_] := Boole /@ (feasible[#, budget] & /@ allMasks);
optFor[budget_] := Module[{fp = Pick[allMasks, feasibleQ[budget], 1], best},
   best = Max[valueOf /@ fp];
   <|"value" -> best|>];

opt12 = optFor[budget12];
opt16 = optFor[budget16];
members12 = First @ Select[membersOf /@ Pick[allMasks, valueOf /@ allMasks, opt12["value"]], feasible[#, budget12] &];
members16 = First @ Select[membersOf /@ Pick[allMasks, valueOf /@ allMasks, opt16["value"]], feasible[#, budget16] &];
Print["exact optimum at budget ", budget12, ": ", opt12["value"], " points, plan: ", members12];
Print["exact optimum at budget ", budget16, ": ", opt16["value"], " points, plan: ", members16];

assertionEnum = opt12["value"] == planData["optimum_12"]["exposure_points"] &&
   opt16["value"] == planData["optimum_16"]["exposure_points"] &&
   Sort[members12] == Sort[planData["optimum_12"]["members"]] &&
   Sort[members16] == Sort[planData["optimum_16"]["members"]];
If[assertionEnum, pass["enumeration matches data/results/plans.json"], fail["enumeration mismatch"]];

(* ---------- 2. Gupta-Mittal Monte Carlo cross-check ---------- *)
baselineYear = inst["baseline_year"];
tcYear = inst["migration_start_year"] + inst["migration_duration_years"];
cdfPts = Join[{{0., 0.}}, N @ inst["qday_distribution"]["cumulative_points_years"],
   {{N[inst["qday_distribution"]["linear_tail_to_years"]], 1.}}];
cdf[t_] := Piecewise[
   Prepend[Table[{cdfPts[[k, 2]] + (cdfPts[[k + 1, 2]] - cdfPts[[k, 2]])/(cdfPts[[k + 1, 1]] - cdfPts[[k, 1]])*(t - cdfPts[[k, 1]]),
      cdfPts[[k, 1]] <= t <= cdfPts[[k + 1, 1]]}, {k, Length[cdfPts] - 1}], {0., t <= 0}]];
mcN = inst["qday_distribution"]["monte_carlo_samples"];
mcSeed = 20261123;
SeedRandom[mcSeed];
sampleQDay := Module[{u = RandomReal[], k = 1},
   While[cdfPts[[k + 1, 2]] < u, k++];
   cdfPts[[k, 1]] + (u - cdfPts[[k, 2]])/(cdfPts[[k + 1, 2]] - cdfPts[[k, 2]])*(cdfPts[[k + 1, 1]] - cdfPts[[k, 1]])];
exposedFraction[tq_, x_] := Which[
   tq <= tcYear - baselineYear, 1.,
   tq >= tcYear - baselineYear + x, 0.,
   True, (tcYear - baselineYear + x - tq)/x];
efWolfram = N[Total @ Table[exposedFraction[sampleQDay, 10.], {mcN}]/mcN];
efPython = scoreData["calibration_anchor"]["reproduction"]["E_f"];
mcSE = Sqrt[0.25/mcN];
mcDelta = Abs[efWolfram - efPython];
assertionMC = mcDelta <= 2 mcSE;
Print["Gupta-Mittal E[f] (X=10, start 2026): Wolfram MC ", nf[efWolfram, 4],
  " vs Python exact ", nf[efPython, 4], " (delta ", nf[mcDelta, 3],
  " = ", nf[mcDelta/mcSE, 2], " SE; gate 2 SE = ", nf[2 mcSE, 3], ")"];
If[assertionMC, pass["Monte Carlo agrees with the scoring module"], fail["Monte Carlo mismatch"]];

(* ---------- 3. penalized cost (exact diagonal, QUBO-style) ---------- *)
lambda = 12; mu = 20;
prtBit = 2^(Position[ids, "PRT"][[1, 1]] - 1);
gwyBit = 2^(Position[ids, "GWY"][[1, 1]] - 1);
costPenalty[mask_Integer, budget_] := -valueOf[membersOf[mask]] + lambda*Max[0, costOf[membersOf[mask]] - budget] +
   If[BitAnd[mask, prtBit] > 0 && BitAnd[mask, gwyBit] == 0, mu, 0];
checkPenalty[budget_] := Module[{bestPen, bestCon},
   bestPen = First @ MinimalBy[allMasks, costPenalty[#, budget] &];
   bestCon = First @ MinimalBy[allMasks, If[feasible[#, budget], -valueOf[membersOf[#]], 10^6] &];
   <|"pen" -> membersOf[bestPen], "con" -> membersOf[bestCon],
     "match" -> Sort[membersOf[bestPen]] == Sort[membersOf[bestCon]]|>];
chk12 = checkPenalty[budget12];
chk16 = checkPenalty[budget16];
Print["penalized argmin at 12: ", chk12["pen"], "  constrained: ", chk12["con"], "  match: ", chk12["match"]];
Print["penalized argmin at 16: ", chk16["pen"], "  constrained: ", chk16["con"], "  match: ", chk16["match"]];
If[chk12["match"] && chk16["match"], pass["penalty terms (lambda=12, mu=20) preserve both optima"],
  fail["penalty does not preserve the constrained optimum"]];

(* ---------- 4. Walsh-Hadamard Z decomposition ---------- *)
walshHadamard[costTable_] := Module[{L = Length[costTable], h},
   h = ConstantArray[0., L];
   Do[h[[k + 1]] += costTable[[m + 1]]*(-1)^DigitCount[BitAnd[m, k], 2, 1], {m, 0, L - 1}, {k, 0, L - 1}];
   h/L];
pauliDecomp12 = walshHadamard[N @ Table[costPenalty[m, budget12], {m, 0, 2^n - 1}]];
nonzero12 = Select[Transpose[{allMasks, pauliDecomp12}], Abs[#[[2]]] > 10^-9 &];
maxWeight12 = Max[BitLength /@ Select[nonzero12[[All, 1]], # > 0 &]];
(* BitLength is used as the mask's Hamming weight here. For the paper's
   masks (all <= 63) BitLength and PopCount agree on the maximum (both give 6,
   attained at mask 63); for general masks compute the Hamming weight with
   DigitCount[m, 2, 1] instead of relying on BitLength. *)
Print["Z decomposition at budget 12: ", Length[nonzero12], " nonzero terms of ", 2^n,
  ", max Pauli weight ", maxWeight12];
(* verify: rebuilding the diagonal cost from the Z terms must reproduce it exactly *)
recon12 = Table[Sum[nonzero12[[j, 2]]*(-1)^DigitCount[BitAnd[m, nonzero12[[j, 1]]], 2, 1],
    {j, Length[nonzero12]}], {m, 0, 2^n - 1}];
If[Max[Abs[recon12 - Table[costPenalty[m, budget12], {m, 0, 2^n - 1}]]] > 10^-6,
  fail["Z decomposition does not reconstruct the cost table"]];
pass["Z decomposition reconstructs the cost table (max dev " <>
  ToString[nf[Max[Abs[recon12 - Table[costPenalty[m, budget12], {m, 0, 2^n - 1}]]], 2]] <> ")"];

(* ---------- 5. QAOA statevector ---------- *)
(* mixer[beta] implements e^{-i beta X} = RX(2 beta) per qubit;
   phase layer implements e^{-i gamma C}, C the diagonal minimization cost *)
mixer[beta_] := KroneckerProduct @@ ConstantArray[
    {{Cos[beta], -I Sin[beta]}, {-I Sin[beta], Cos[beta]}}, n];
phaseLayer[gamma_, costTable_] := DiagonalMatrix[Exp[-I gamma costTable]];
uniform = ConstantArray[1/Sqrt[2^n], 2^n];
qaoaState[gamma_, beta_, costTable_] := mixer[beta].(phaseLayer[gamma, costTable].uniform);
qaoaState2[g1_, b1_, g2_, b2_, costTable_] :=
   mixer[b2].(phaseLayer[g2, costTable].mixer[b1].(phaseLayer[g1, costTable].uniform));
expectC[psi_, costTable_] := Abs[psi]^2 . costTable;
probFeasible[psi_, budget_] := (Abs[psi]^2) . feasibleQ[budget];

(* Fast compiled evaluator for the angle search. The mixer is a product of
   identical one-qubit unitaries, so applying it to the amplitude vector is
   a 6-step butterfly transform; p=1 is the special case g2 = b2 = 0
   (b = 0 leaves the second mixer stage at the identity). It is verified
   against the dense matrix path below before any search uses it. *)
qaoaProbsFast = Compile[{{g1, _Real}, {b1, _Real}, {g2, _Real}, {b2, _Real}, {ct, _Real, 1}},
   Module[{v = Table[0. + 0.*I, {2^n}], nv = v, c1, s1, c2, s2, qq, z},
    c1 = Cos[b1]; s1 = Sin[b1]; c2 = Cos[b2]; s2 = Sin[b2];
    v = Table[Exp[-I g1 ct[[z]]]/8., {z, 2^n}];
    Do[nv = Table[c1*v[[z]] + (-I) s1*v[[BitXor[z - 1, qq] + 1]], {z, 2^n}]; v = nv,
     {qq, {1, 2, 4, 8, 16, 32}}];
    v = Table[v[[z]]*Exp[-I g2 ct[[z]]], {z, 2^n}];
    Do[nv = Table[c2*v[[z]] + (-I) s2*v[[BitXor[z - 1, qq] + 1]], {z, 2^n}]; v = nv,
     {qq, {1, 2, 4, 8, 16, 32}}];
    Abs[v]^2],
   CompilationTarget -> "WVM"];

(* compiled landscape: <C> over a whole (gamma, beta) grid in one call,
   flattened beta-major (gamma index fastest) *)
landscapeC = Compile[{{ct, _Real, 1}, {gs, _Real, 1}, {bs, _Real, 1}},
   Module[{out = Table[0., {Length[bs]*Length[gs]}], v, nv, c, s, qq, z, j, k = 1, acc},
    Do[
     c = Cos[b]; s = Sin[b];
     v = Table[Exp[-I g ct[[z]]]/8., {z, 2^n}];
     Do[nv = Table[c*v[[z]] + (-I) s*v[[BitXor[z - 1, qq] + 1]], {z, 2^n}]; v = nv,
      {qq, {1, 2, 4, 8, 16, 32}}];
     acc = 0.;
     Do[acc += (Re[v[[j]]]^2 + Im[v[[j]]]^2)*ct[[j]], {j, 2^n}];
     out[[k++]] = acc,
     {b, bs}, {g, gs}];
    out],
   CompilationTarget -> "WVM"];

(* verify the fast paths against the dense matrix path before using them *)
testTable = N @ Table[costPenalty[m, budget12], {m, 0, 2^n - 1}];
SeedRandom[20261123];
fastCheck = Max @@ Table[
    With[{g = RandomReal[{0, 2. Pi}], b = RandomReal[{0, Pi}],
          g2 = RandomReal[{0, 2. Pi}], b2 = RandomReal[{0, Pi}]},
      Abs[0.5 Total[Abs[qaoaProbsFast[g, b, g2, b2, testTable] -
         Abs[qaoaState2[g, b, g2, b2, testTable]]^2]]]],
    {8}];
If[fastCheck > 10^-10,
  fail["fast QAOA evaluator disagrees with the dense matrix path: " <> ToString[fastCheck]]];
pass["fast QAOA evaluator matches the dense matrix path (max TVD over 8 random angles = " <>
  ToString[nf[fastCheck, 2]] <> ")"];
landCheck = Max @@ Table[
    With[{g = RandomReal[{0, 2. Pi}], b = RandomReal[{0, Pi}]},
      Abs[expectC[qaoaState[g, b, testTable], testTable] -
        First[landscapeC[testTable, {g}, {b}]]]],
    {6}];
If[landCheck > 10^-8,
  fail["compiled landscape disagrees with the matrix path: " <> ToString[landCheck]]];
pass["compiled landscape matches the matrix path (max dev over 6 random angles = " <>
  ToString[nf[landCheck, 2]] <> ")"];

(* numerical gradient of <C> at given angles (central differences);
   obj takes the angle list, so it works for p=1 and p=2 alike *)
gradC[angles_List, ct_, obj_] := Module[{h = 10^-6},
   Table[Module[{xp = angles, xm = angles},
      xp[[k]] += h; xm[[k]] -= h;
      (obj[xp, ct] - obj[xm, ct])/(2 h)],
    {k, Length[angles]}]];
objVecP1[a_List, ct_] := qaoaProbsFast[a[[1]], a[[2]], 0., 0., ct] . ct;
objVecP2[a_List, ct_] := qaoaProbsFast[a[[1]], a[[2]], a[[3]], a[[4]], ct] . ct;
(* NumericQ-guarded scalar forms for FindMinimum (it probes the objective
   symbolically first; the compiled call must only see numbers) *)
objP1Num[g_?NumericQ, b_?NumericQ, ct_] := qaoaProbsFast[g, b, 0., 0., ct] . ct;
objP2Num[g1_?NumericQ, b1_?NumericQ, g2_?NumericQ, b2_?NumericQ, ct_] :=
   qaoaProbsFast[g1, b1, g2, b2, ct] . ct;

(* angle normalization to gamma in [0, 2*pi), beta in [0, pi): the state is
   invariant under (gamma, beta) -> (2*pi - gamma, pi - beta), so pick the
   representative with the same objective value *)
normalizeAngles[g_, b_, ct_] := Module[{bN = Mod[b, Pi], gN, gM},
   gN = Mod[g, 2. Pi]; gM = Mod[2. Pi - g, 2. Pi];
   If[Abs[objVecP1[{gN, bN}, ct] - objVecP1[{g, b}, ct]] <=
      Abs[objVecP1[{gM, Mod[Pi - b, Pi]}, ct] - objVecP1[{g, b}, ct]],
    {gN, bN}, {gM, Mod[Pi - b, Pi]}]];


(* Honest angle search (replaces the old 97x49 grid + +-0.2 box search):
   1. dense gamma grid, 2401 points per 2*pi (the cost table spans `span`,
      so <C>(gamma) contains frequencies up to `span` and the Nyquist bound
      is 2*span points per 2*pi - the grid here is ~12x denser), times a
      601-point beta grid;
   2. unconstrained local refinement (FindMinimum, no search box) from the
      12 best grid points; the p=1 result is global by grid density;
   3. p=2: coarse 4-D grid screen, then multi-start unconstrained local
      refinement from the 8 best grid points plus 4 seeded random starts.
      The p=2 result is the best point found, NOT a certified global
      optimum, and is labeled as such wherever it is quoted. *)
angleSearchMethod = "p=1: gamma grid 2401 points/2pi x beta grid 601 points, then unconstrained local refinement from the 12 best grid points (no search box); p=1 is global by grid density (gamma step ~0.0026 rad vs the Nyquist bound pi/<cost span>). p=2: coarse 4-D grid screen (13x13x7x7) then multi-start unconstrained refinement from 12 starts - the best point found, not certified global";

runQAOA[budget_, targetMask_] := Module[
   {costTable, span, gridG, gridB, landscape, order, best, bestC, res, g0, b0, k, g, b,
    gA, bA, psi, probs, starts, gGrid2, bGrid2, p2pts, p2vals, g1, b1, g2, b2, best2,
    g1o, b1o, g2o, b2o, psi2, probs2, grad1, grad2},
   costTable = N @ Table[costPenalty[m, budget], {m, 0, 2^n - 1}];
   span = Max[costTable] - Min[costTable];
   gridG = Subdivide[0., 2. Pi, 2400];
   gridB = Subdivide[0., Pi, 600];
   landscape = landscapeC[costTable, gridG, gridB];
   order = Ordering[landscape, 12];
   best = {Infinity, 0., 0.};
   Do[
    k = order[[j]];
    g0 = gridG[[Mod[k - 1, Length[gridG]] + 1]];
    b0 = gridB[[Quotient[k - 1, Length[gridG]] + 1]];
    res = Quiet @ FindMinimum[objP1Num[g, b, costTable],
        {{g, g0}, {b, b0}}, MaxIterations -> 500, AccuracyGoal -> 8, PrecisionGoal -> 8];
    If[MatchQ[res, {_?NumberQ, _List}] && res[[1]] < best[[1]],
     best = {res[[1]], g /. res[[2]], b /. res[[2]]}],
    {j, Length[order]}];
   If[best[[1]] >= Mean[costTable],
    fail["p=1 refinement did not improve on the uniform point for budget " <> ToString[budget]]];
   {gA, bA} = normalizeAngles[best[[2]], best[[3]], costTable];
   psi = qaoaState[gA, bA, costTable];
   probs = Abs[psi]^2;
   grad1 = Norm[gradC[{gA, bA}, costTable, objVecP1]];
   If[grad1 > 10^-3,
    fail["refined p=1 angles are not stationary for budget " <> ToString[budget] <>
      ": |grad <C>| = " <> ToString[grad1]]];
   (* p=2: coarse 4-D grid screen (13 gamma1 x 13 gamma2 x 7 beta1 x 7 beta2),
      then multi-start unconstrained refinement from the 8 best grid points
      plus 4 seeded random starts. The p=2 result is the best point found,
      NOT a certified global optimum, and is labeled as such wherever it is
      quoted. *)
   gGrid2 = Subdivide[0., 2. Pi, 12];
   bGrid2 = Subdivide[0., Pi, 6];
   p2pts = Flatten[Table[{g1, b1, g2, b2},
      {b1, bGrid2}, {g1, gGrid2}, {b2, bGrid2}, {g2, gGrid2}], 3];
   p2vals = Flatten[Table[qaoaProbsFast[g1, b1, g2, b2, costTable] . costTable,
      {b1, bGrid2}, {g1, gGrid2}, {b2, bGrid2}, {g2, gGrid2}], 3];
   starts = Join[
     p2pts[[Ordering[p2vals, 8]]],
     Module[{}, SeedRandom[budget];
      Table[{RandomReal[{0, 2 Pi}], RandomReal[{0, Pi}],
        RandomReal[{0, 2 Pi}], RandomReal[{0, Pi}]}, {4}]]];
   best2 = {Infinity, starts[[1]]};
   Do[
    res = Quiet @ FindMinimum[objP2Num[g1, b1, g2, b2, costTable],
        {{g1, s[[1]]}, {b1, s[[2]]}, {g2, s[[3]]}, {b2, s[[4]]}},
        MaxIterations -> 800, AccuracyGoal -> 8, PrecisionGoal -> 8];
    If[MatchQ[res, {_?NumberQ, _List}] && res[[1]] < best2[[1]],
     best2 = {res[[1]], {g1, b1, g2, b2} /. res[[2]]}],
    {s, starts}];
   {g1o, b1o, g2o, b2o} = best2[[2]];
   psi2 = qaoaState2[g1o, b1o, g2o, b2o, costTable];
   probs2 = Abs[psi2]^2;
   grad2 = Norm[gradC[{g1o, b1o, g2o, b2o}, costTable, objVecP2]];
   <|"budget" -> budget,
     "cost_table" -> costTable,
     "angle_search" -> angleSearchMethod,
     "cost_span" -> span,
     "angles_p1" -> N[{gA, bA}, 8], "expected_cost_p1" -> N[expectC[psi, costTable], 8],
     "probs_p1" -> N[probs, 8],
     "p_feasible_p1" -> N[probFeasible[psi, budget], 8],
     "p_optimal_p1" -> N[probs[[targetMask + 1]], 8],
     "grad_norm_p1" -> N[grad1, 4],
     "p_opt_uniform" -> N[1/2^n, 8], "p_feas_uniform" -> N[Mean[feasibleQ[budget]], 8],
     "angles_p2" -> N[{g1o, b1o, g2o, b2o}, 8], "expected_cost_p2" -> N[best2[[1]], 8],
     "probs_p2" -> N[probs2, 8],
     "p_feasible_p2" -> N[probFeasible[psi2, budget], 8],
     "p_optimal_p2" -> N[probs2[[targetMask + 1]], 8],
     "grad_norm_p2" -> N[grad2, 4],
     "optimum_mask" -> targetMask|>];

mask12 = maskOf[planData["optimum_12"]["members"]];
mask16 = maskOf[planData["optimum_16"]["members"]];
maskRanked12 = maskOf[planData["ranked_list_12"]["members"]];
rankedValue12 = planData["ranked_list_12"]["exposure_points"];

Print["running the honest angle search (p=1, p=2) at budget 12 ..."];
q12 = runQAOA[budget12, mask12];
Print["  p=1 angles (gamma,beta) = ", N[q12["angles_p1"], 6],
  "  <C> = ", nf[q12["expected_cost_p1"], 4],
  "  P(feasible) = ", nf[q12["p_feasible_p1"], 4],
  "  P(optimal) = ", nf[q12["p_optimal_p1"], 4],
  "  |grad| = ", nf[q12["grad_norm_p1"], 2]];
Print["  p=2 (best found, multi-start) <C> = ", nf[q12["expected_cost_p2"], 4],
  "  P(feasible) = ", nf[q12["p_feasible_p2"], 4],
  "  P(optimal) = ", nf[q12["p_optimal_p2"], 4]];
Print["running the honest angle search (p=1, p=2) at budget 16 ..."];
q16 = runQAOA[budget16, mask16];
Print["  p=1 angles (gamma,beta) = ", N[q16["angles_p1"], 6],
  "  <C> = ", nf[q16["expected_cost_p1"], 4],
  "  P(optimal) = ", nf[q16["p_optimal_p1"], 4],
  "  |grad| = ", nf[q16["grad_norm_p1"], 2]];
Print["  p=2 (best found, multi-start) <C> = ", nf[q16["expected_cost_p2"], 4],
  "  P(optimal) = ", nf[q16["p_optimal_p2"], 4]];

(* uniform baseline for comparison *)
uniformFeasible12 = Mean[feasibleQ[budget12]];
uniformOpt12 = 1/2^n;
Print["uniform baseline at budget 12: P(feasible) = ", nf[uniformFeasible12, 4],
  ", P(optimal) = 1/", 2^n];

(* ---------- 6. Quantum Framework matrix rebuild + seeded sampler (budget 12, p=1) ---------- *)
(* convention check: QF probability list index i must equal our LSB-first mask i *)
convState = QuantumState[StringJoin[ToString /@ IntegerDigits[5, 2, n]]]; (* index 5 -> "000101" MSB-left *)
convProbs = convState["ProbabilitiesList"];
If[Not[ListQ[convProbs]] || Length[convProbs] =!= 2^n || Abs[convProbs[[6]] - 1] > 10^-8,
  fail["QF bit-order convention check: got " <> ToString[convProbs]]];
pass["QF bit-order convention: list index i = LSB-first mask i"];

(* The QF rebuild applies the same matrices through QuantumCircuitOperator /
   QuantumOperator objects, so the comparison below is a deterministic
   self-consistency check of the construction, not a sampling test: it must
   agree to machine precision, with no sampling-style threshold. *)
hCirc = QuantumCircuitOperator[Table["H" -> k, {k, n}]];
psiQF = hCirc[QuantumState[StringJoin[Table["0", {n}]]]];
psiQF = QuantumOperator[DiagonalMatrix[Exp[-I N[q12["angles_p1"][[1]]] q12["cost_table"]]]][psiQF];
psiQF = QuantumOperator[mixer[N[q12["angles_p1"][[2]]]]][psiQF];
probsQF = N[psiQF["ProbabilitiesList"], 8];
tvd = 0.5*Total[Abs[probsQF - q12["probs_p1"]]];
Print["QF matrix rebuild vs analytic statevector: TVD = ", nf[tvd, 3],
  " (deterministic comparison, machine precision)"];
assertionTVD = tvd <= 10^-10;
If[assertionTVD, pass["QF rebuild matches the analytic statevector to machine precision"],
  fail["QF rebuild deviates from the analytic statevector beyond machine precision"]];

(* Seeded 4096-shot sample FROM THE EXACT p=1 STATEVECTOR (not sampled from
   a circuit; a genuine circuit-sampling run needs a Classiq/platform
   account and is out of scope for this demo). Seed aligned with the app's
   sampler seed; the RNG implementations differ (Wolfram vs mulberry32), so
   the two 4096-shot samples agree statistically, not sample-by-sample. *)
shots = 4096;
SeedRandom[mcSeed];
sampleMasks = RandomChoice[q12["probs_p1"] -> allMasks, shots];
counts = AssociationThread[allMasks, Lookup[Counts[sampleMasks], allMasks, 0]];
sampleFeasible = Total[Pick[Values[counts], feasibleQ[budget12], 1]]/shots;
sampleOptimal = counts[mask12]/shots;
sampleBeatsRanked = Total[Pick[Values[counts],
     Table[Boole[feasible[m, budget12] && valueOf[membersOf[m]] > rankedValue12], {m, allMasks}], 1]]/shots;
expectedCostSample = (Values[counts] . q12["cost_table"])/shots;
Print["seeded ", shots, "-shot sample from the exact statevector: P(feasible) = ", nf[sampleFeasible, 4],
  ", P(optimal) = ", nf[sampleOptimal, 4],
  ", P(beats ranked list) = ", nf[sampleBeatsRanked, 4],
  ", <C> = ", nf[expectedCostSample, 4]];

(* ---------- 7. figures ---------- *)
chartsDir = FileNameJoin[{root, "charts"}];
If[! DirectoryQ[chartsDir], CreateDirectory[chartsDir]];
green = RGBColor[0.16, 0.50, 0.20]; red = RGBColor[0.72, 0.26, 0.23]; gold = RGBColor[0.85, 0.65, 0.10];
(* landscape on a dense grid via the compiled path (481 gamma x 241 beta),
   with the search-found global optimum marked; the old 97x49 grid missed
   the narrow global basin entirely *)
gridG = Subdivide[0., 2. Pi, 480]; gridB = Subdivide[0., Pi, 240];
landVals = landscapeC[q12["cost_table"], gridG, gridB];
landscapePts = Flatten[Table[{gridG[[gi]], gridB[[bi]], landVals[[(bi - 1)*Length[gridG] + gi]]},
    {bi, Length[gridB]}, {gi, Length[gridG]}], 1];
Export[FileNameJoin[{chartsDir, "landscape_p1_b12.png"}],
  ListDensityPlot[landscapePts, ColorFunction -> "TemperatureMap",
   FrameLabel -> {"gamma (cost angle)", "beta (mixer angle)"},
   PlotLabel -> "QAOA p=1 expectation landscape, budget 12; gold = global minimum (dense-grid search)",
   PlotLegends -> Automatic,
   Epilog -> {RGBColor[0.55, 0.4, 0.0], AbsolutePointSize[11], Point[q12["angles_p1"]],
     White, AbsolutePointSize[4], Point[q12["angles_p1"]]},
   ImageSize -> 640, AspectRatio -> 1/2]];

barColors = Table[If[feasibleQ[budget12][[m + 1]] == 1, green, red], {m, 0, 2^n - 1}];
barColors = ReplacePart[barColors, mask12 + 1 -> gold];
Export[FileNameJoin[{chartsDir, "distribution_b12.png"}],
  BarChart[q12["probs_p1"], ChartStyle -> barColors,
   Frame -> True, FrameLabel -> {"plan (0..63, one bit per project)", "probability"},
   PlotLabel -> "QAOA p=1 distribution at the search-found angles (budget 12): green = feasible, gold = exact optimum",
   ImageSize -> 900, AspectRatio -> 1/3, BarSpacing -> 0.02]];

top = Take[ReverseSortBy[Normal @ AssociationThread[allMasks -> N[q12["probs_p1"], 8]], Last], 10];
topCounts = Lookup[counts, Keys[top]]/shots;
Export[FileNameJoin[{chartsDir, "qf_sample_vs_exact.png"}],
  BarChart[Transpose[{Values[top], topCounts}],
   ChartLabels -> (Rotate[StringRiffle[membersOf[#], ","], 45 Degree] & /@ Keys[top]),
   ChartStyle -> {RGBColor[0.25, 0.35, 0.65], RGBColor[0.85, 0.55, 0.15]},
   Frame -> True, FrameLabel -> {"first-wave plan", "probability"},
   PlotLabel -> "Exact statevector vs seeded 4096-shot sample (top 10 plans, budget 12)",
   ImageSize -> 900, ChartLegends -> {"exact p=1", "seeded sample"}, AspectRatio -> 1/2.4]];

Export[FileNameJoin[{chartsDir, "budget_flip.png"}],
  BarChart[{planData["optimum_12"]["exposure_points"], planData["ranked_list_12"]["exposure_points"],
    planData["optimum_16"]["exposure_points"]},
   ChartLabels -> {"exact optimum\n12 weeks", "naive ranked list\n12 weeks", "exact optimum\n16 weeks"},
   ChartStyle -> {green, red, gold}, Frame -> True,
   FrameLabel -> {None, "baseline exposure (points)"},
   PlotLabel -> "The same six systems: four extra weeks flip the best first wave (70 -> 92 points)",
   ImageSize -> 640, AspectRatio -> 1/2]];

(* Mosca curve: E[f] vs start year, X = 10, Y = 6, midline.
   Same closed-form segment sum as data/scoring.py: E[f] = integral of
   (linear f) * (piecewise-linear CDF density) over the union of knots. *)
efAtStartYear[year_] := Module[{tc = N[year + inst["migration_duration_years"] - baselineYear], x = 10.,
   knots, total = 0., a, b, fa, fb, sf, sd, i, f},
   f[t_] := Which[t <= tc, 1., t >= tc + x, 0., True, (tc + x - t)/x];
   knots = Sort @ DeleteDuplicates @ N @ Join[
      Select[cdfPts[[All, 1]], 0 <= # <= cdfPts[[-1, 1]] &],
      {tc, tc + x, 0., cdfPts[[-1, 1]]}];
   Do[a = knots[[i]]; b = knots[[i + 1]];
     fa = f[a]; fb = f[b];
     sf = (fb - fa)/(b - a); sd = (cdf[b] - cdf[a])/(b - a);
     total += sd*(fa*(b - a) + sf*(b - a)^2/2),
     {i, Length[knots] - 1}];
   total];
efCheck = efAtStartYear[inst["migration_start_year"]];
If[Abs[efCheck - efPython] > 10^-3, fail["closed-form E[f] curve disagrees with the scoring module: " <> ToString[efCheck]]];
pass["closed-form Mosca curve matches the scoring module (E[f](2026) = " <> ToString[nf[efCheck, 4]] <> ")"];
years = Range[2025, 2034];
efCurve = efAtStartYear /@ years;
Export[FileNameJoin[{chartsDir, "mosca_curve.png"}],
  ListLinePlot[Transpose[{years, efCurve}], Frame -> True, Mesh -> All,
   FrameLabel -> {"migration start year", "expected exposed fraction E[f]"},
   PlotLabel -> "HNDL exposure vs start year (Gupta & Mittal 2026 model, X=10, Y=6, midline)",
   Epilog -> {Red, AbsolutePointSize[7], Point[{2026, efCurve[[2]]}], Point[{2030, efCurve[[6]]}],
     Black, Inset["2026: E[f] = " <> ToString[nf[efCurve[[2]], 3]], {2026.4, efCurve[[2]] - 0.035}],
     Inset["2030: E[f] = " <> ToString[nf[efCurve[[6]], 3]], {2030.4, efCurve[[6]] - 0.035}]},
   ImageSize -> 640, AspectRatio -> 1/2]];

Export[FileNameJoin[{chartsDir, "exposure_scores.png"}],
  BarChart[vals,
   ChartLabels -> ids,
   ChartStyle -> {green, green, RGBColor[0.35, 0.45, 0.65], gold, RGBColor[0.55, 0.55, 0.55], RGBColor[0.55, 0.55, 0.55]},
   Frame -> True, FrameLabel -> {None, "baseline exposure (points)"},
   PlotLabel -> "First-wave candidates: baseline HNDL exposure from the paper's model + business-impact weighting",
   ImageSize -> 720, AspectRatio -> 1/2]];

(* ---------- 8. export ---------- *)
countsStr = AssociationThread[ToString /@ Keys[counts], Values[counts]];
result = <|
   "schema" -> "qwave-wolfram-pipeline/1.1.0",
   "generated" -> DateString["ISODateTime"],
   "wolfram_version" -> $Version,
   "qf_paclet_version" -> PacletObject["Wolfram/QuantumFramework"]["Version"],
   "mc_seed" -> mcSeed, "shots" -> shots,
   "sample_note" -> "seeded 4096-shot sample drawn from the exact p=1 statevector (not sampled from a circuit); seed aligned with the app's mulberry32 seed, RNG implementations differ",
   "penalty" -> <|"lambda_budget" -> lambda, "mu_dependency" -> mu|>,
   "exact" -> <|
     "optimum_12" -> <|"members" -> members12, "mask" -> mask12, "cost_weeks" -> costOf[members12], "points" -> opt12["value"]|>,
     "optimum_16" -> <|"members" -> members16, "mask" -> mask16, "cost_weeks" -> costOf[members16], "points" -> opt16["value"]|>,
     "ranked_list_12_mask" -> maskRanked12|>,
   "mosca" -> <|
     "ef_x10_start2026_wolfram_mc" -> efWolfram, "ef_x10_start2026_python_exact" -> efPython,
     "mc_delta" -> mcDelta, "mc_se" -> mcSE, "mc_assertion_gate" -> 2 mcSE,
     "ef_curve_years" -> years, "ef_curve_values" -> efCurve|>,
   "decomposition" -> <|"nonzero_terms" -> Length[nonzero12], "max_weight" -> maxWeight12,
        "z_terms" -> Map[<|"mask" -> #[[1]], "coeff" -> #[[2]]|> &, nonzero12]|>,
   "qaoa_12" -> q12, "qaoa_16" -> q16,
   "qf" -> <|
     "convention_check" -> "passed",
     "tvd_exact_vs_qf" -> tvd,
     "tvd_note" -> "deterministic matrix rebuild comparison, machine precision, no sampling threshold",
     "sample_counts" -> countsStr,
     "sample_feasible" -> sampleFeasible, "sample_optimal" -> sampleOptimal,
     "sample_beats_ranked" -> sampleBeatsRanked, "sample_expected_cost" -> expectedCostSample|>,
   "assertions" -> <|"enumeration" -> assertionEnum, "monte_carlo" -> assertionMC,
     "penalty" -> chk12["match"] && chk16["match"], "tvd" -> assertionTVD|>|>;
outPath = FileNameJoin[{here, "qwave_planner.json"}];
Export[outPath, result];
Print["written: ", outPath];
Print["ALL WOLFRAM ASSERTIONS PASSED"];
