"""Assemble the ESL-style deck: reference CSS/JS (from the published Rule 7.5
deck) + this demo's slide body. Keeps the deck pixel-faithful to the ESL
template without retyping the style sheet."""

from pathlib import Path

REF = Path(r"C:\Users\danie\Public-html-pages\misra-rule-7-5-zero-program\technical\index.html")
HERE = Path(__file__).resolve().parent

ref = REF.read_text(encoding="utf-8")

head = ref[: ref.index("<body>")]
head = head.replace(
    "<title>MISRA C:2025 Rule 7.5 Zero Program | Sourcegraph + Parasoft | ESL</title>",
    "<title>Q-Wave Planner | Provably Optimal PQC Migration Waves | ESL</title>",
)
head = head.replace(
    'content="ESL technical brief: the MISRA C:2025 Rule 7.5 zero program on driftregion/iso14229, a measured Sourcegraph + Parasoft closed loop, from an 8-finding seeded pilot to zero, then scaled to 1,095 whole-repo findings with three mechanical batch fixes.',
    'content="ESL MantiQ workflow demo: Q-Wave Planner, provably optimal PQC migration waves for a six-project bank instance, Wolfram Quantum Framework simulation, a Lean 4 certificate with 0 sorry, and an executable wave planner.',
)

script = ref[ref.index("<script>"): ref.index("</script>") + len("</script>")]

body = (HERE / "body.html").read_text(encoding="utf-8")

extra_style = "<style>\n.hl{color:var(--blue-text)}\n.fchart svg{max-height:470px}\n.shotrow img{border-radius:6px;background:#fff}\n.t5 table{font-size:14px}\n.t5 th,.t5 td{padding:7px 8px}\n</style>\n</head>"
head = head.replace("</head>", extra_style)

out = head + "<body>\n" + body + "\n\n" + script + "\n</body>\n</html>\n"
(HERE / "index.html").write_text(out, encoding="utf-8")
print("wrote", HERE / "index.html", f"({len(out):,} bytes)")
