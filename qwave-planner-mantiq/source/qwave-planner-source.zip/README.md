# Q-Wave Planner: Provably Optimal PQC Migration Waves

A MantiQ-workflow demo (Wolfram simulation → Lean 4 proof → executable system)
built as an independent capability demonstration inspired by
[Q.security](https://www.q.security)'s
post-quantum readiness problem. Not affiliated with Q.security; Meridian Bank is
fictional.

**The question it answers:** which systems should a bank migrate to post-quantum
cryptography this quarter? A crypto inventory alone gives you a ranked list. A
wave planner gives you the plan that is *provably* the best one under your
budget, your dependencies, and the harvest-now-decrypt-later clock.

## The demo instance

Six candidate migrations at Meridian Bank, a weekly engineering budget, and one
dependency (the customer portal PRT requires the shared gateway GWY first):

| bit | id   | system                    | weeks | points | requires |
|-----|------|---------------------------|-------|--------|----------|
| 0   | PAY  | Payments TLS termination  | 5     | 35     | -        |
| 1   | VPN  | Core banking VPN (IPsec)  | 7     | 35     | -        |
| 2   | SIGN | Code signing (updates)    | 3     | 19     | -        |
| 3   | PRT  | Customer portal TLS       | 6     | 44     | GWY      |
| 4   | GWY  | Shared edge gateway (mTLS)| 4     | 13     | -        |
| 5   | SSO  | HR SaaS SSO certificates  | 2     | 7      | -        |

Points come from the HNDL exposure model in Gupta & Mittal 2026
(*Cybersecurity* 9:147, `s42400-026-00579-2.pdf` in the repository root):
`points = round(40 · E[f]) + business_bonus`, with the midline GRI-2024 Q-day
distribution, migration start 2026, per-asset data lifetimes X = 10/20/15/1
years for the four HNDL assets (X = 10 shown in the charts), Y = 6-year
migration. SIGN and SSO are non-HNDL integrity assets and use P(Tq < Tc)
instead. The business bonus is an explicit demo assumption, not from the paper.

**The story the numbers tell:**

- At the default **12 engineer-weeks**, the exact optimum is **{PAY, VPN} = 70
  points** (cost 12, unique). The naive exposure-ranked list picks **{PRT, GWY,
  SSO} = 64**: the top-ranked portal drags its prerequisite in and leaves 6
  points on the table. The gap is budget-specific: at 8, 9, 13, 15 and
  16-20 weeks the ranked list happens to match the optimum; at 10-11 it is 4
  points short, at 12 it is 6 short, at 14 it is 1 short.
- At the live-event budget of **16 weeks**, the optimum flips to **{PAY, GWY,
  PRT} = 92 points** (cost 15, unique). Every 12-week-feasible plan is worth
  ≤ 70 < 92: four extra weeks change *which* systems get fixed, not just how
  many.

## The three pipelines (they cross-check each other)

### 1. Data (`data/`)

- `instance.json`: the instance and the scoring rule.
- `scoring.py`: exact integral of the Gupta & Mittal exposure model plus a
  seeded 200k-sample Monte Carlo cross-check (seed 20261123). Writes
  `results/scoring.json`.
- `plan_search.py`: enumerates all 64 plans per budget, finds the exact optima,
  runs the ranked-list greedy, asserts the story properties. Writes
  `results/plans.json`.

### 2. Wolfram (`wolfram/`)

`qwave_planner.wl` (WolframScript + Quantum Framework paclet 1.6.5):

- verifies its enumeration against `results/plans.json`;
- verifies its Monte Carlo E[f] against the Python exact integral;
- encodes the penalized budget-12 cost on 6 qubits and proves the penalty terms
  (λ = 12 budget, μ = 20 dependency) preserve both constrained optima;
- computes the Walsh-Hadamard Z decomposition (56 non-identity terms, 57
  counting the identity, max Pauli weight 6) and checks it reconstructs the
  cost table;
- runs QAOA p=1 and p=2 at both budgets over a dense angle grid, multi-start
  search (angles are search-found, not certified globally optimal): at budget
  12, p=1 P(optimal) = 0.0604 (3.9× uniform) and p=2 = 0.6998 (44.8×, best
  found); at budget 16, p=1 = 0.0470 (3.0×) and p=2 = 0.0075 (best found,
  not certified globally optimal). The enumeration
  layer, not the sampler, makes the decision;
- rebuilds the p=1 circuit with Quantum Framework objects (TVD vs analytic:
  5.9e-16), draws a seeded 4096-shot sample from the exact statevector
  (P(feasible) = 0.5139, P(optimal) = 0.0645, P(beats ranked) = 0.1167), and
  cross-checks the Python Monte Carlo (delta 0.00154 = 1.4 standard errors);
- exports every chart in `charts/` and the numbers in `qwave_planner.json`.

Run (~5 min): `wolframscript -file wolfram/qwave_planner.wl`. The run ends with
`ALL WOLFRAM ASSERTIONS PASSED`.

### 3. Lean 4 (`lean/`)

`QWavePlanner.lean` (module `Hackton.QWavePlanner`, Lean/Mathlib v4.33.0)
certifies the headline facts by `decide` over the full 64-plan enumeration:
optimum 70 unique at mask 3 (budget 12), the ranked-list plan is 6 points
short, optimum 92 unique at mask 25 (budget 16), and the flip theorem
(`qwave_budget_flip`: every 12-week-feasible plan ≤ 70 < 92). Build: 3006 jobs,
0 errors, 0 warnings, 0 sorries (`qwave_planner_build.log`). At this scale the
proofs are decision procedures over the finite enumeration; past roughly 30
projects they would move to real inductive proofs over an ILP formulation.

### 4. Classiq artifact (`classiq/`)

- `generate_qmod.py`: turns the verified Z decomposition into
  `qwave_planner.qmod`, a 6-qubit QAOA p=1 model written with the Classiq SDK's
  own QMOD writer (valid by construction), with the search-found angles and 56
  non-identity Pauli-Z phase terms (57 with the identity) embedded. Its
  built-in self-check re-parses the file and asserts TVD < 1e-9 against the
  Wolfram p=1 distribution (achieved: 4.4e-13).
- `qwave_planner_classiq.py`: SDK driver (create_model, synthesize, execute
  4096 shots, compare against the Wolfram statevector prediction; `--run` for
  the cloud). **Not run in the demo** (the demo simulates locally); it requires
  Classiq account credentials. Its feasibility definition matches the planner:
  weeks ≤ budget and PRT ⇒ GWY (23 of 64 plans feasible at budget 12).

### 5. Executable system (`app/index.html`)

A self-contained web app, the demo centerpiece: business-first chain
(business unit → application → platform → component), live budget slider with
64-plan re-enumeration, exact-optimum vs naive exposure-ranked-list comparison,
a QAOA p=1 statevector computed live in the browser with the Wolfram
search-found angles (matches Wolfram's stored distribution to TVD 5.9e-16 at
the anchor budgets), a seeded 4096-shot sampler, the Lean certificate,
wave-plan → remediation tickets with runbooks, and the paper's E[f]-vs-start-year
exposure curve (2026 start: 0.366 exposed; 2030 start: 0.539). Rebuild with
`py -3 app/build_app.py` (reads `app/template.html` + the pipeline results).

## Reproduction order

```text
py -3 data/scoring.py
py -3 data/plan_search.py
wolframscript -file wolfram/qwave_planner.wl
lake build Hackton.QWavePlanner        # in the Lean project (see lean/README pointer)
py -3.12 classiq/generate_qmod.py
py -3 app/build_app.py
```

## Presentation

- `presentation/`: the ESL-style slide deck (self-contained HTML).
- `video/`: the demo video walkthrough and its production assets.

## Attribution

- Exposure model: Gupta & Mittal 2026, *Cybersecurity* 9:147
  (`s42400-026-00579-2.pdf`). Q-day distribution: GRI 2024 expert elicitation,
  midline scenario.
- Wolfram Quantum Framework, Lean 4 + Mathlib, Classiq QMOD: the three
  verification legs of the MantiQ workflow.
