"""Re-record scenes 03 and 12 with zoom-corrected scroll targets (CSS zoom 1.5)."""
import pathlib
import sys

SKILL = pathlib.Path(r"C:\Users\danie\.agents\skills\esl-demo-video\examples\web-playwright")
sys.path.insert(0, str(SKILL))
from recorder import Recorder  # noqa: E402

ZOOM = 1.5
project = pathlib.Path(__file__).parent.resolve()
app = (project.parent / "app" / "index.html").as_uri()


def scroll_to(page, elem_id, block="center"):
    return page.evaluate(
        f"document.getElementById('{elem_id}').scrollIntoView({{block:'{block}', behavior:'instant'}})"
    )


with Recorder(project, zoom=ZOOM, slow_mo=250) as rec:
    # Scene 03: instance overview at budget 12 (narration 22.7 s -> need >= 26 s)
    with rec.scene("03", app) as page:
        rec.hold(5)
        scroll_to(page, "projTable")
        rec.event("project table centered")
        rec.hold(9)
        scroll_to(page, "budgetSlider")
        rec.event("budget slider centered")
        rec.hold(10)

    # Scene 12: Mosca deadline curve (narration 22.4 s -> need >= 26 s)
    with rec.scene("12", app) as page:
        scroll_to(page, "mosca")
        rec.event("Mosca curve centered")
        rec.hold(13)
        scroll_to(page, "moscaNote")
        rec.event("curve note centered")
        rec.hold(13)
