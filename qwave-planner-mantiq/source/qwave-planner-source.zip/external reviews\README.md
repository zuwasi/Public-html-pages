# External reviews

This folder is where external reviewer messages and findings land before they are acted on.

- Current external reviewer channel: `C:\Projects\Q.security-review\` (read-only evidence tree:
  `AMP_MESSAGE_FIX.txt`, `REVIEW_FINDINGS_FIX.md`, `checks\` with verification scripts and logs).
- Rule (see `C:\Users\danie\AGENTS.md`, "External Reviews Workflow"): before each decision point
  and before creating any final product, check for new reviewer feedback, verify the claims,
  then act, push back with evidence, or ask Daniel.
- Disposition log: `disposition.md` in this folder records what was accepted, what was
  challenged and why.
