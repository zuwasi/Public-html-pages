"""Build app/index.html from app/template.html plus the verified pipeline data.

Injects, as an inline JSON blob:
  - the six projects (data/instance.json, verbatim)
  - the per-project exposure points (data/results/scoring.json)
  - the Wolfram pipeline output subsets (wolfram/qwave_planner.json):
    QAOA p=1 angles and full 64-state distributions for the two anchor
    budgets, the QF sampler reference stats, and the Mosca E[f] curve.

Everything the app computes (enumeration, optimum, ranked list, QAOA
statevector, sampling) is recomputed live in the browser; the injected
numbers are the certified anchors it must agree with.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
instance = json.loads((ROOT.parent / "data" / "instance.json").read_text(encoding="utf-8"))
scoring = json.loads((ROOT.parent / "data" / "results" / "scoring.json").read_text(encoding="utf-8"))
wl = json.loads((ROOT.parent / "wolfram" / "qwave_planner.json").read_text(encoding="utf-8"))

embed = {
    "projects": instance["projects"],
    "value": [r["exposure_points"] for r in scoring["projects"]],
    "penalty": wl["penalty"],
    "budget_default": instance["budget_weeks_default"],
    "budget_live": instance["budget_weeks_live"],
    "opt12_points": wl["exact"]["optimum_12"]["points"],
    "shots": wl["shots"],
    "mc_seed": wl["mc_seed"],
    "wolfram": {
        "qaoa_12": {
            "angles_p1": wl["qaoa_12"]["angles_p1"],
            "probs_p1": wl["qaoa_12"]["probs_p1"],
            "p_optimal_p1": wl["qaoa_12"]["p_optimal_p1"],
        },
        "qaoa_16": {
            "angles_p1": wl["qaoa_16"]["angles_p1"],
            "probs_p1": wl["qaoa_16"]["probs_p1"],
            "p_optimal_p1": wl["qaoa_16"]["p_optimal_p1"],
        },
        "qf": {
            "sample_feasible": wl["qf"]["sample_feasible"],
            "sample_optimal": wl["qf"]["sample_optimal"],
            "sample_beats_ranked": wl["qf"]["sample_beats_ranked"],
            "tvd_exact_vs_qf": wl["qf"]["tvd_exact_vs_qf"],
        },
        "mosca": {
            "ef_curve_years": wl["mosca"]["ef_curve_years"],
            "ef_curve_values": wl["mosca"]["ef_curve_values"],
            "ef_x10_start2026_python_exact": wl["mosca"]["ef_x10_start2026_python_exact"],
        },
    },
}

template = (ROOT / "template.html").read_text(encoding="utf-8")
assert "/*__EMBEDDED_DATA__*/" in template
out = template.replace("/*__EMBEDDED_DATA__*/", json.dumps(embed, separators=(",", ":")))
(ROOT / "index.html").write_text(out, encoding="utf-8")
print("wrote", ROOT / "index.html", f"({len(out):,} bytes, {len(embed['wolfram']['qaoa_12']['probs_p1'])} probs embedded)")