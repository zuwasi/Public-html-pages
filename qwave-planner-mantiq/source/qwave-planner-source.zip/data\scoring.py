"""
Exposure scoring for the Q-Wave Planner demo.

Reimplements the timing-risk model of:

    Ankit Gupta and Shilpi Mittal, "Post-quantum readiness and cryptographic
    transition planning for enterprise cloud", Cybersecurity 9:147 (2026),
    https://doi.org/10.1186/s42400-026-00579-2

Model (paper, "Exposure-risk model"):

    Tq = Q-day (calendar year), Ts = migration start year, Tc = Ts + Y.
    f(Tq; Ts, X, Y) = min(1, max(0, (min(Tq, Tc) - (Tq - X)) / X))

    Metrics: P(f > 0) and E[f], the expected exposed fraction of the
    confidentiality window, under a Q-day distribution.

Q-day distribution (paper Table 5, GRI 2024 expert elicitation, midline):
    F(5)=0.098, F(10)=0.265, F(15)=0.505, F(20)=0.711, F(30)=0.847,
    linear tail to 40 years. Baseline year 2025.

The paper estimates E[f] by Monte Carlo with N = 200,000 samples (standard
error <= 1.1e-3). Because f(Tq) is piecewise linear and the CDF is piecewise
linear, E[f] also has a closed form; this script computes the exact value and
validates it against a seeded Monte Carlo run of the paper's estimator.

Published anchor for calibration: X = 10, Ts = 2026, Y = 6, midline ->
P(f > 0) = 0.59, E[f] = 0.37 (paper abstract and Table 7).

Outputs data/results/scoring.json consumed by every later stage, so the
numbers in the Wolfram run, the Lean certificate and the web app all trace
back to this file.
"""

import json
import math
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INSTANCE = json.loads((ROOT / "instance.json").read_text(encoding="utf-8"))

BASELINE_YEAR = INSTANCE["baseline_year"]
TS = INSTANCE["migration_start_year"]
Y = INSTANCE["migration_duration_years"]
TC = TS + Y
POINTS = INSTANCE["qday_distribution"]["cumulative_points_years"]
TAIL_END = INSTANCE["qday_distribution"]["linear_tail_to_years"]
N_MC = INSTANCE["qday_distribution"]["monte_carlo_samples"]

# Seed chosen once; recorded in the output so the run is reproducible.
MC_SEED = 20261123  # Q.security launch date, fixed seed


def cdf(t: float) -> float:
    """Midline Q-day CDF F(t), t in years since the baseline year.

    Piecewise-linear through the GRI points, linear tail to the tail end,
    clamped to [0, 1].
    """
    pts = [(0.0, 0.0)] + [(float(a), float(b)) for a, b in POINTS] + [(float(TAIL_END), 1.0)]
    if t <= 0:
        return 0.0
    if t >= TAIL_END:
        return 1.0
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= t <= x1:
            return y0 + (y1 - y0) * (t - x0) / (x1 - x0)
    raise AssertionError("unreachable")


def exposed_fraction(t_q_years: float, x_years: float) -> float:
    """f at a Q-day t_q (years since baseline) for a system whose migration
    completes at TC with confidentiality window X. Piecewise linear in t_q:
    1 while Tq <= Tc, then decaying linearly to 0 at Tc + X."""
    if t_q_years <= TC - BASELINE_YEAR:
        return 1.0
    upper = TC - BASELINE_YEAR + x_years
    if t_q_years >= upper:
        return 0.0
    return (upper - t_q_years) / x_years


def expected_exposure_exact(x_years: float) -> float:
    """E[f] computed exactly by integrating f over the piecewise-linear CDF.

    Breaks [0, TAIL_END] at the CDF knots and at Tc and Tc + X, where f has
    corners, and sums the exact integrals of the linear x linear products.
    """
    knots = sorted({0.0, float(TAIL_END), TC - BASELINE_YEAR, TC - BASELINE_YEAR + x_years}
                   | {float(a) for a, _ in POINTS})
    knots = [k for k in knots if 0.0 <= k <= TAIL_END]
    total = 0.0
    for a, b in zip(knots, knots[1:]):
        fa, fb = exposed_fraction(a, x_years), exposed_fraction(b, x_years)
        da, db = cdf(a), cdf(b)
        # integral of (linear f) * (linear density) over [a, b]
        slope_f = (fb - fa) / (b - a)
        slope_d = (db - da) / (b - a)
        # f(t) = fa + slope_f*(t-a); density = slope_d
        # integral = slope_d * [fa*(b-a) + slope_f*(b-a)^2/2]
        total += slope_d * (fa * (b - a) + slope_f * (b - a) ** 2 / 2)
    return total


def prob_any_exposure_exact(x_years: float) -> float:
    """P(f > 0): a CRQC arrives strictly before Tc + X."""
    return cdf(TC - BASELINE_YEAR + x_years)


def expected_exposure_monte_carlo(x_years: float, n: int = N_MC, seed: int = MC_SEED) -> float:
    """The paper's Algorithm 1 estimator: sample Q-days from the CDF, average f."""
    rng = random.Random(seed)
    pts = [(0.0, 0.0)] + [(float(a), float(b)) for a, b in POINTS] + [(float(TAIL_END), 1.0)]

    def sample_qday() -> float:
        u = rng.random()
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            if u <= y1:
                # inverse of the linear piece
                if y1 == y0:
                    return x1
                return x0 + (u - y0) / (y1 - y0) * (x1 - x0)
        return float(TAIL_END)

    tc = TC - BASELINE_YEAR
    acc = 0.0
    for _ in range(n):
        t = sample_qday()
        if t <= tc:
            acc += 1.0
        else:
            upper = tc + x_years
            acc += max(0.0, (upper - t) / x_years)
    return acc / n


def main() -> None:
    rows = []
    for p in INSTANCE["projects"]:
        x = float(p["data_lifetime_years"])
        if p["hndl"] and x > 0:
            ef_exact = expected_exposure_exact(x)
            ef_mc = expected_exposure_monte_carlo(x)
            p_any = prob_any_exposure_exact(x)
            risk = ef_exact
            risk_source = "E[f] (confidentiality, HNDL)"
        else:
            # Forward-integrity asset (code signing, SAML signing certificates): the paper's threat model
            # separates retroactive confidentiality loss from forward
            # integrity/authentication risk. A forged signature matters once a
            # CRQC exists, so exposure = P(Tq < Tc) = F(Y years since baseline).
            ef_exact = cdf(TC - BASELINE_YEAR)
            ef_mc = ef_exact
            p_any = ef_exact
            risk = ef_exact
            risk_source = "P(Tq < Tc) (forward integrity)"
        score = int(round(40.0 * risk)) + p["business_bonus"]
        rows.append({
            "id": p["id"],
            "name": p["name"],
            "risk_source": risk_source,
            "x_years": x,
            "ef_exact": round(ef_exact, 4),
            "ef_monte_carlo": round(ef_mc, 4),
            "ef_mc_delta": round(abs(ef_exact - ef_mc), 4),
            "p_any_exposure": round(p_any, 4),
            "exposure_points": score,
            "business_bonus": p["business_bonus"],
            "cost_weeks": p["cost_weeks"],
        })

    # Calibration check against the paper's published anchor.
    anchor_x = 10.0
    anchor_ef = expected_exposure_exact(anchor_x)
    anchor_p = prob_any_exposure_exact(anchor_x)

    out = {
        "model": {
            "source": "Gupta & Mittal 2026, Cybersecurity 9:147, doi:10.1186/s42400-026-00579-2",
            "baseline_year": BASELINE_YEAR,
            "start_year": TS,
            "completion_year": TC,
            "y_years": Y,
            "mc_seed": MC_SEED,
            "mc_samples": N_MC,
        },
        "calibration_anchor": {
            "paper": {"X": 10, "start_2026": {"P_f_gt_0": 0.59, "E_f": 0.37}},
            "reproduction": {"P_f_gt_0": round(anchor_p, 4), "E_f": round(anchor_ef, 4)},
        },
        "projects": rows,
    }

    results_dir = ROOT / "results"
    results_dir.mkdir(exist_ok=True)
    (results_dir / "scoring.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")

    print(f"Calibration anchor (X=10, start 2026, Y=6, midline):")
    print(f"  paper:        P(f>0) = 0.59, E[f] = 0.37")
    print(f"  reproduction: P(f>0) = {anchor_p:.4f}, E[f] = {anchor_ef:.4f}")
    print()
    header = f"{'id':5s} {'risk source':32s} {'X':>3s} {'E[f]':>7s} {'MC':>7s} {'P(f>0)':>7s} {'score':>5s} {'weeks':>5s}"
    print(header)
    print("-" * len(header))
    for r in rows:
        print(f"{r['id']:5s} {r['risk_source']:32s} {r['x_years']:3.0f} "
              f"{r['ef_exact']:7.4f} {r['ef_monte_carlo']:7.4f} {r['p_any_exposure']:7.4f} "
              f"{r['exposure_points']:5d} {r['cost_weeks']:5d}")


if __name__ == "__main__":
    main()