"""Record the Q-Wave Planner app scenes for the ESL demo video.

Run: py -3 record_app.py
Scenes: 03 (instance, budget 12), 04 (plan cards), 06 (QAOA panel),
10 (budget flip to 16). Scene 09 still (Lean certificate) is captured too.
Each clip must outlast its narration (voice seconds + ~3 s).
"""
import pathlib
import sys

SKILL = pathlib.Path(r"C:\Users\danie\.agents\skills\esl-demo-video\examples\web-playwright")
sys.path.insert(0, str(SKILL))
from recorder import Recorder  # noqa: E402

project = pathlib.Path(__file__).parent.resolve()
app = (project.parent / "app" / "index.html").as_uri()

with Recorder(project, zoom=1.5, slow_mo=250) as rec:
    # Scene 03: instance overview at budget 12 (narration 22.7 s -> need >= 26 s)
    with rec.scene("03", app) as page:
        rec.hold(5)
        page.evaluate("window.scrollTo(0, document.getElementById('projTable').offsetTop - 220)")
        rec.event("scrolled to project table")
        rec.hold(9)
        page.evaluate("window.scrollTo(0, document.getElementById('chain').offsetTop - 240)")
        rec.event("business chain in view")
        rec.hold(6)
        page.evaluate("window.scrollTo(0, 0)")
        rec.event("back to top")
        rec.hold(8)

    # Scene 04: plan cards at budget 12 (narration 20.3 s -> need >= 24 s)
    with rec.scene("04", app) as page:
        page.evaluate("window.scrollTo(0, document.getElementById('cardOpt').offsetTop - 260)")
        rec.event("plan cards in view")
        rec.hold(8)
        page.locator("#cardRanked").scroll_into_view_if_needed()
        rec.event("ranked card centered")
        rec.hold(8)
        page.evaluate("window.scrollTo(0, document.getElementById('projTable').offsetTop - 220)")
        rec.event("project table for context")
        rec.hold(9)

    # Scene 06: live QAOA panel (narration 22.9 s -> need >= 27 s)
    with rec.scene("06", app) as page:
        page.evaluate("window.scrollTo(0, document.getElementById('qBars').offsetTop - 300)")
        rec.event("QAOA panel in view")
        rec.hold(8)
        page.click("#btnSample")
        rec.event("sampled 4096 shots")
        rec.hold(8)
        page.evaluate("window.scrollTo(0, document.getElementById('sampleStats').offsetTop - 320)")
        rec.event("sample stats in view")
        rec.hold(11)

    # Scene 10: budget flip 12 -> 16 (narration 21.7 s -> need >= 26 s)
    with rec.scene("10", app) as page:
        rec.hold(6)
        page.locator("#budgetSlider").fill("16")
        rec.event("budget slider moved to 16")
        rec.hold(7)
        page.evaluate("window.scrollTo(0, document.getElementById('flipBanner').offsetTop - 320)")
        rec.event("flip banner in view")
        rec.hold(7)
        page.evaluate("window.scrollTo(0, document.getElementById('tickets').offsetTop - 260)")
        rec.event("reordered tickets in view")
        rec.hold(8)

    # Scene 09 still: Lean certificate panel as an element screenshot
    with rec.scene("09", app) as page:
        el = page.locator("#leanCert")
        el.scroll_into_view_if_needed()
        rec.hold(2)
        section = page.locator(".panel:has(#leanCert)")
        section.screenshot(path=str(rec.clips / "scene09.png"))
        rec.event("scene09 still saved")