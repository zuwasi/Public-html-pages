"""Record scene 12 (Mosca deadline curve, live in the app) for the ESL demo video."""
import pathlib
import sys

SKILL = pathlib.Path(r"C:\Users\danie\.agents\skills\esl-demo-video\examples\web-playwright")
sys.path.insert(0, str(SKILL))
from recorder import Recorder  # noqa: E402

project = pathlib.Path(__file__).parent.resolve()
app = (project.parent / "app" / "index.html").as_uri()

with Recorder(project, zoom=1.5, slow_mo=250) as rec:
    with rec.scene("12", app) as page:
        page.evaluate("window.scrollTo(0, document.getElementById('mosca').offsetTop - 300)")
        rec.event("Mosca curve in view")
        rec.hold(9)
        page.evaluate("window.scrollTo(0, document.getElementById('mosca').offsetTop - 180)")
        rec.event("scrolled closer")
        rec.hold(9)
        page.evaluate("window.scrollTo(0, document.getElementById('moscaNote').offsetTop - 400)")
        rec.event("note in view")
        rec.hold(9)