"""
Classiq SDK driver for the Q-Wave Planner demo.

Builds the p=1 QAOA model with the Classiq SDK (the same @qfunc functions that
classiq/generate_qmod.py writes to qwave_planner.qmod), and, when run with
--run and a Classiq account (CLASSIQ_ID and CLASSIQ_KEY, or an authenticated
`classiq login`), synthesizes it and executes 4096 shots on the Classiq
simulator, comparing the sampled optimum and feasibility probabilities
against the Wolfram pipeline's exact-statevector prediction.

It is NOT part of the demo run: the demo executes quantum simulation locally
in Wolfram (Quantum Framework), per the MantiQ workflow's separation of
simulation from platform artifacts. Without --run this file only builds the
model locally; the cloud calls in --run require network access and an account.

Expected agreement (from wolfram/qwave_planner.json, budget-12, p=1,
search-found angles, not claimed globally optimal):
  P(optimal mask 3 = {PAY, VPN}) ~ 0.0604  (4096-shot noise ~ +-0.008)
  P(feasible)                    ~ 0.5069  (4096-shot noise ~ +-0.016)
Feasibility means: total engineer-weeks <= 12 AND PRT implies GWY; 23 of the
64 candidate sets satisfy it (uniform probability 0.3594).
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from generate_qmod import N, OPT_MASK, PROJECTS, WOLFRAM  # noqa: E402

SHOTS = 4096
EXPECTED_P_OPT = WOLFRAM["qaoa_12"]["p_optimal_p1"]
EXPECTED_P_FEAS = WOLFRAM["qaoa_12"]["p_feasible_p1"]
BUDGET = WOLFRAM["qaoa_12"]["budget"]
INSTANCE = json.loads((ROOT.parent / "data" / "instance.json").read_text(encoding="utf-8"))
WEEKS = [next(p["cost_weeks"] for p in INSTANCE["projects"] if p["id"] == pid) for pid in PROJECTS]


def is_feasible(mask: int) -> bool:
    """A plan is feasible when its engineer-weeks fit the budget and taking
    PRT (bit 3) also takes GWY (bit 4), the hard dependency in the instance."""
    if sum(WEEKS[i] for i in range(N) if mask >> i & 1) > BUDGET:
        return False
    return not (mask >> 3 & 1) or bool(mask >> 4 & 1)


def count_feasible() -> int:
    return sum(1 for mask in range(2**N) if is_feasible(mask))


def run_cloud() -> None:
    from classiq import ExecutionPreferences, create_model, execute, set_execution_preferences, show, synthesize

    from generate_qmod import main as qwave_main

    model = create_model(qwave_main)
    set_execution_preferences(model, ExecutionPreferences(num_shots=SHOTS))
    qprog = synthesize(model)
    print("synthesized:", type(qprog).__name__)

    # Uncomment to open the circuit visualization in the browser (needs login):
    # with show(qprog):
    #     pass

    results = execute(qprog)
    counts = results.parsed_counts

    # Bit convention: Classiq returns the `sampled` QArray as a bit string in
    # qubit-index order; project k is bit k. Convert to the demo's LSB-first
    # mask and verify the reversal on a few shots the first time you run it.
    total_opt = 0
    total_feasible = 0
    for item in counts:
        bits = item.state["sampled"]  # e.g. '110000'
        mask = int(bits[::-1], 2)
        total_opt += item.shots if mask == OPT_MASK else 0
        total_feasible += item.shots if is_feasible(mask) else 0

    p_opt = total_opt / SHOTS
    p_feas = total_feasible / SHOTS
    print(f"P(optimal) = {p_opt:.4f}  (Wolfram exact: {EXPECTED_P_OPT:.4f})")
    print(f"P(feasible) = {p_feas:.4f}  (Wolfram exact: {EXPECTED_P_FEAS:.4f})")
    assert abs(p_opt - EXPECTED_P_OPT) < 0.02, "sampled optimum probability drifted from the exact prediction"
    assert abs(p_feas - EXPECTED_P_FEAS) < 0.04, "sampled feasibility probability drifted from the exact prediction"
    print("PASS: Classiq execution agrees with the Wolfram statevector prediction")


def run_local() -> None:
    from classiq import create_model

    from generate_qmod import main as qwave_main

    model = create_model(qwave_main)
    print(f"built Classiq model from the @qfunc functions (no cloud call): {type(model).__name__}")
    print(f"to synthesize and execute {SHOTS} shots, run with --run (requires a Classiq account)")
    print(f"expected at the search-found p=1 angles: P(optimal) ~ {EXPECTED_P_OPT:.4f}, "
          f"P(feasible) ~ {EXPECTED_P_FEAS:.4f} ({count_feasible()}/64 sets feasible)")


def main() -> None:
    try:
        import classiq  # noqa: F401
    except ImportError:
        sys.exit("classiq not installed: pip install classiq (running the model also requires a Classiq account)")
    if "--run" in sys.argv:
        run_cloud()
    else:
        run_local()


if __name__ == "__main__":
    main()