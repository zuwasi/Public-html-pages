import Mathlib.Tactic

/-!
# Q-Wave Planner certificates

This module certifies the Q-Wave Planner demo instance: six candidate PQC
migration projects at Meridian Bank, a weekly engineering budget, and a
dependency (the customer portal PRT requires the gateway GWY first).

Project order (bit `i` of the 6-bit plan mask selects project `i`):

| bit | id   | cost (weeks) | exposure points | requires |
|-----|------|--------------|-----------------|----------|
| 0   | PAY  | 5            | 35              | -        |
| 1   | VPN  | 7            | 35              | -        |
| 2   | SIGN | 3            | 19              | -        |
| 3   | PRT  | 6            | 44              | GWY      |
| 4   | GWY  | 4            | 13              | -        |
| 5   | SSO  | 2            | 7               | -        |

The certified facts (each discharged by `decide` over the full 64-plan
enumeration, so no heuristic is trusted):

1. At the default budget of 12 engineer-weeks the unique optimum is
   mask 3 = {PAY, VPN} worth 70 points.
2. The naive exposure-ranked list's pick at budget 12, mask 56 =
   {PRT, GWY, SSO}, is feasible but worth only 64 points: 6 short of the
   optimum.
3. At the live-event budget of 16 the unique optimum is
   mask 25 = {PAY, GWY, PRT} worth 92 points.
4. The budget flip: every budget-12-feasible plan is worth at most 70 < 92,
   so four extra weeks change the whole wave, not just its size.

These constants must agree with `data/results/plans.json` (the Python
enumeration) and the Wolfram exact run; all three pipelines were checked
against each other in the demo build.
-/

/-- Exposure points per project, in bit order PAY, VPN, SIGN, PRT, GWY, SSO. -/
def qwaveValue : Fin 6 → Nat := ![35, 35, 19, 44, 13, 7]

/-- Engineer-week cost per project, in the same bit order. -/
def qwaveCost : Fin 6 → Nat := ![5, 7, 3, 6, 4, 2]

/-- Bit `i` of the plan mask: 1 when project `i` is in the first wave. -/
def qwaveBit (m : Fin 64) (i : Fin 6) : Nat := (m.val >>> i.val) % 2

/-- Total exposure points of a plan (the scoring rule is additive). -/
def qwaveValueOf (m : Fin 64) : Nat := ∑ i, qwaveValue i * qwaveBit m i

/-- Total engineer-week cost of a plan. -/
def qwaveCostOf (m : Fin 64) : Nat := ∑ i, qwaveCost i * qwaveBit m i

/-- The dependency constraint: PRT (bit 3) requires GWY (bit 4). -/
def qwaveDepOK (m : Fin 64) : Bool := !(qwaveBit m 3 == 1) || qwaveBit m 4 == 1

/-- Feasibility of a plan under a weekly budget: cost fits and dependencies hold. -/
def qwaveFeasible (m : Fin 64) (budget : Nat) : Bool :=
  qwaveCostOf m ≤ budget && qwaveDepOK m

/-- The default-budget optimum {PAY, VPN} = mask 3 is feasible and worth 70. -/
theorem qwave_opt12_attained :
    qwaveFeasible 3 12 = true ∧ qwaveValueOf 3 = 70 := by
  decide

/-- At budget 12 no feasible plan beats 70 points. -/
theorem qwave_opt12_bound : ∀ m : Fin 64, qwaveFeasible m 12 = true → qwaveValueOf m ≤ 70 := by
  decide

/-- The budget-12 optimum is unique: only mask 3 reaches 70 points. -/
theorem qwave_opt12_unique :
    ∀ m : Fin 64, qwaveFeasible m 12 = true → qwaveValueOf m = 70 → m = 3 := by
  decide

/-- The naive exposure-ranked list's budget-12 pick {PRT, GWY, SSO} = mask 56 is
feasible but worth 64, six points short of the optimum. -/
theorem qwave_ranked12_loses :
    qwaveFeasible 56 12 = true ∧ qwaveValueOf 56 = 64 ∧ qwaveValueOf 56 < 70 := by
  decide

/-- The live-budget optimum {PAY, GWY, PRT} = mask 25 is feasible and worth 92. -/
theorem qwave_opt16_attained :
    qwaveFeasible 25 16 = true ∧ qwaveValueOf 25 = 92 := by
  decide

/-- At budget 16 no feasible plan beats 92 points. -/
theorem qwave_opt16_bound : ∀ m : Fin 64, qwaveFeasible m 16 = true → qwaveValueOf m ≤ 92 := by
  decide

/-- The budget-16 optimum is unique: only mask 25 reaches 92 points. -/
theorem qwave_opt16_unique :
    ∀ m : Fin 64, qwaveFeasible m 16 = true → qwaveValueOf m = 92 → m = 25 := by
  decide

/-- The budget flip: every budget-12-feasible plan is worth at most 70, and the
budget-16 optimum is worth 92, so the 16-week optimum exceeds every
budget-12-feasible plan's value: four extra weeks change the whole wave. -/
theorem qwave_budget_flip :
    ∀ m : Fin 64, qwaveFeasible m 12 = true → qwaveValueOf m ≤ 70 ∧ qwaveValueOf 25 = 92 := by
  decide
