"""
Plan search for the Q-Wave Planner demo.

Enumerates all 2^6 = 64 possible first-wave selections over the six candidate
migrations, filters by budget and the gateway->portal dependency, finds the
exact optimum for the default budget (12 engineer-weeks) and the live-event
budget (16), and compares against a naive exposure-ranked list (greedy by
exposure-per-week, the simplest prioritizer).

This script is the ground truth every other stage is checked against:
the Wolfram exact run, the Lean certificate and the web app must all agree
with these numbers.

Story properties asserted here (they are the point of the demo):
  1. At budget 12 the exact optimum avoids the gateway+portal wave.
  2. The naive exposure-ranked list picks the gateway+portal wave anyway
     (the top-ranked item drags its prerequisite in) and loses points.
  3. At budget 16 the exact optimum flips to gateway+portal+payments and
     exceeds every budget-12-feasible plan's value.

Outputs data/results/plans.json.
"""

import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INSTANCE = json.loads((ROOT / "instance.json").read_text(encoding="utf-8"))
SCORING = json.loads((ROOT / "results" / "scoring.json").read_text(encoding="utf-8"))

PROJECTS = INSTANCE["projects"]
IDS = [p["id"] for p in PROJECTS]
COST = {p["id"]: p["cost_weeks"] for p in PROJECTS}
VALUE = {r["id"]: r["exposure_points"] for r in SCORING["projects"]}
REQUIRES = {p["id"]: p.get("requires") for p in PROJECTS}

B12 = INSTANCE["budget_weeks_default"]
B16 = INSTANCE["budget_weeks_live"]


def plan_from_mask(mask: int) -> list[str]:
    return [IDS[i] for i in range(len(IDS)) if mask >> i & 1]


def cost_of(ids: list[str]) -> int:
    return sum(COST[i] for i in ids)


def value_of(ids: list[str]) -> int:
    return sum(VALUE[i] for i in ids)


def feasible(ids: list[str], budget: int) -> bool:
    if cost_of(ids) > budget:
        return False
    for i in ids:
        req = REQUIRES[i]
        if req and req not in ids:
            return False
    return True


def enumerate_plans(budget: int) -> list[dict]:
    rows = []
    for mask in range(1 << len(IDS)):
        ids = plan_from_mask(mask)
        rows.append({
            "mask": mask,
            "members": ids,
            "cost_weeks": cost_of(ids),
            "exposure_points": value_of(ids),
            "feasible": feasible(ids, budget),
        })
    return rows


def optimum(budget: int) -> tuple[int, list[str]]:
    best_value, best = -1, None
    for mask in range(1 << len(IDS)):
        ids = plan_from_mask(mask)
        if feasible(ids, budget) and value_of(ids) > best_value:
            best_value, best = value_of(ids), ids
    return best_value, best


def unique_optimum(budget: int) -> bool:
    best_value, _ = optimum(budget)
    winners = [m for m in range(1 << len(IDS))
               if feasible(plan_from_mask(m), budget) and value_of(plan_from_mask(m)) == best_value]
    return len(winners) == 1


def ranked_list_plan(budget: int) -> list[str]:
    """Greedy prioritizer: walk the systems ranked by exposure-per-week and
    take each one whose full requirement chain fits in the remaining budget."""
    order = sorted(IDS, key=lambda i: VALUE[i] / COST[i], reverse=True)
    chosen: list[str] = []
    for i in order:
        candidate = chosen + [i]
        # pull in prerequisites, cheapest-first is irrelevant here: each
        # project has at most one prerequisite in this instance
        chain = list(candidate)
        req = REQUIRES[i]
        if req and req not in chain:
            chain.append(req)
        if feasible(chain, budget):
            chosen = chain
    return chosen


def main() -> None:
    plans12 = enumerate_plans(B12)
    plans16 = enumerate_plans(B16)
    opt12, ids12 = optimum(B12)
    opt16, ids16 = optimum(B16)
    ranked12 = ranked_list_plan(B12)
    ranked16 = ranked_list_plan(B16)

    print(f"Budget {B12} weeks: optimum {opt12} points with {ids12} "
          f"(cost {cost_of(ids12)}), unique: {unique_optimum(B12)}")
    print(f"  ranked list picks {ranked12} -> {value_of(ranked12)} points "
          f"(cost {cost_of(ranked12)}), {opt12 - value_of(ranked12)} points short")
    print(f"Budget {B16} weeks: optimum {opt16} points with {ids16} "
          f"(cost {cost_of(ids16)}), unique: {unique_optimum(B16)}")
    print(f"  ranked list picks {ranked16} -> {value_of(ranked16)} points")
    print(f"Budget change {B12} -> {B16}: optimum moves {ids12} -> {ids16}, "
          f"{opt12} -> {opt16} points (+{100 * (opt16 - opt12) / opt12:.0f}%)")
    best_feasible_at_12 = opt12
    print(f"Every budget-{B12}-feasible plan is worth <= {best_feasible_at_12}; "
          f"the budget-{B16} optimum is {opt16} > {best_feasible_at_12}: "
          f"four extra weeks change the whole wave, not just its size")

    # --- story assertions ---
    assert not ("PRT" in ids12 and "GWY" in ids12), \
        "budget-12 optimum must avoid the gateway+portal wave"
    assert opt12 > value_of(ranked12), "ranked list must lose at budget 12"
    assert sorted(ids16) == sorted(["GWY", "PRT", "PAY"]), ids16
    assert "GWY" in ids16 and "PRT" in ids16, "budget 16 optimum must contain the gateway+portal wave"
    assert opt16 > opt12
    assert all(value_of(plan_from_mask(m)) <= opt12
               for m in range(1 << len(IDS)) if feasible(plan_from_mask(m), B12))
    assert unique_optimum(B12) and unique_optimum(B16)

    out = {
        "budget_default": B12,
        "budget_live": B16,
        "optimum_12": {"members": ids12, "cost_weeks": cost_of(ids12), "exposure_points": opt12},
        "optimum_16": {"members": ids16, "cost_weeks": cost_of(ids16), "exposure_points": opt16},
        "ranked_list_12": {"members": ranked12, "cost_weeks": cost_of(ranked12),
                           "exposure_points": value_of(ranked12)},
        "ranked_list_16": {"members": ranked16, "cost_weeks": cost_of(ranked16),
                           "exposure_points": value_of(ranked16)},
        "plans_12": plans12,
        "plans_16": plans16,
    }
    (ROOT / "results" / "plans.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print("\nwrote data/results/plans.json (64 plans per budget)")


if __name__ == "__main__":
    main()