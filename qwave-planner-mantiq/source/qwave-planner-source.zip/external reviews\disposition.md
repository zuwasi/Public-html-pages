# Reviewer feedback disposition log

## Round 2 (Droid re-verification, 28 Nov 2026) - source: C:\Projects\Q.security-review\AMP_MESSAGE_FIX.txt

Verdict: A-K fixed and independently verified. Residuals R1-R8 + housekeeping.

| Item | Reviewer claim | Verified by Amp | Disposition |
|------|----------------|-----------------|-------------|
| R1 | Stale `sensitivity_note` in data/instance.json ([15,22,7,19,7,8], tie claims wrong) | Recomputed: no-bonus points [15,22,7,19,7,7]; 12-wk optimum unique {PAY,VPN}=37; 16-wk three-way tie at 44 | Accepted; both strings fixed 2026-11-28 |
| R2 | Stale Lean copy + 94-byte build log in C:\Projects\Hackton | Diff confirmed stale values in Hackton copy | Accepted; fresh copy made, `lake build Hackton.QWavePlanner` re-run, log re-tee'd |
| R3 | `py -3` should be `py -3.12` for classiq/generate_qmod.py (SDK only on 3.12) | Confirmed install state | Accepted; README + deck slide 15 fixed |
| R4 | classiq/z_terms.json is dead (nothing reads it) | Confirmed: generate_qmod.py reads z_terms from wolfram/qwave_planner.json | Accepted; deleted |
| R5 | Deck says assertion gate "3 SE = 0.0034", actual gate 2 SE = 0.0022 | Confirmed against wl:140 and qwave_planner.json | Accepted; deck fixed |
| R6 | App/deck overclaim "build would fail if numbers drifted" | Confirmed: no such failure mechanism exists | Accepted; reworded to "certificate is tied to the shipped instance constants; a changed instance needs a re-proved certificate" |
| R7 | Non-anchor QAOA angles presented too strongly | Confirmed: grid search + refinement is an estimate | Accepted; "estimate, not a certified optimum" added to angleNote and badge |
| R8 | Residual overclaims (blanket X=10-year, "3 proofs", "cannot see the flip", "certifies every plan", HNSL acronym, "~4 min", video scene 02 vendor phrasing, catalog AI_NOTES) | Each checked individually; all confirmed or trivially true | Accepted; fixed in template.html, body.html, README.md, wolfram script comments, scenes.md/transcript.md |
| Housekeeping | Not a git repo; leftover servers 8123/8437; leftover files | Confirmed | Accepted; servers killed, leftovers deleted after use |

Honest limits acknowledged: no Classiq cloud run performed; p=2 angles are best-found not certified global; video not watched end-to-end by a human.

Reviewer credit: every R-item checked out; no incorrect findings in this round. The reviewer's note that the deck's "cross-checked by all three pipelines" wording is arithmetic-level (recomputation, not proof) was adopted as the standard phrasing.

## Round 2 completion record (28 Nov 2026)

- R1-R8 all fixed and re-verified: Wolfram re-run twice (clean log, zero warnings, ALL WOLFRAM ASSERTIONS PASSED, qwave_planner.json byte-identical to backup except timestamp), `lake build Hackton.QWavePlanner` 3006 jobs success, build log re-tee'd (93 bytes, lake's natural output), app rebuilt and exercised via app_harness.js, deck rebuilt, video re-voiced (scene 02) and re-recorded (scenes 03, 04, 06, 09, 10, 12) and concatenated (274.6 s, 22.6 MB).
- All Python checks re-run and consistent (verify_scoring, verify_plans_qaoa, verify_sensitivity, verify_extra, verify_extra2, verify_qaoa_counterexample, verify_qmod: TVD 4.384e-13).
- Published publicly, commit 6940bb6 on zuwasi/Public-html-pages main: landing page https://zuwasi.github.io/Public-html-pages/qwave-planner-mantiq/ plus app/, technical/, video/qwave-planner-demo.mp4 (22.6 MB), video/transcript.md, source/qwave-planner-source.zip (5.1 MB). All verified 200 live; landing rendered and inspected on desktop, full-page and 400 px mobile.
- Housekeeping done: ports 8123/8437 freed, tmp_classiq/__pycache__/record_fix2.py/app-plans-b12.png/zip staging removed.
- Deck top bar and verdict slide, and the video end card, now point to the public landing page.
